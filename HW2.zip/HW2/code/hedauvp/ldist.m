function d = ldist(l,p)
    d = abs(dot(l,p)) / sqrt(l(1)^2 + l(2)^2);
end

